const language = {
  "en": "English",
  "vi": "Vietnamese",
  "fr": "French",
  "es": "Spanish",
  "zh": "Chinese"
};
